﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Funcionario
    {
        public String id { get; set; }
        public String nome { get; set; }
        public String tel { get; set; }
    }
}
